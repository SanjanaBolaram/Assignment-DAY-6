 const name = prompt("Enter your name");

 title.innerText += `Welcome ${name} to our site`;




const ctime = document.getElementById('time');


function clock(){
    let date = new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;
}

setInterval(clock,1000);

const dmode = document.getElementById('dark');



dmode.classList.toggle('bgBlack');
document.body.style.color = 'white';


