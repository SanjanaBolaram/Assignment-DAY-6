var multiplier = +prompt("enter a number");
function TimesTable() {
    var display = ""; // The table output HTML
    for (i = 1; i <= 12; i++) {
    
      var result = i * multiplier;
  
      display += multiplier + " * " + i + " = " + result + "<br>";
    }

    document.getElementById("outputDiv").innerHTML = display;
}
TimesTable();